#ifndef SWAP_HUB_SECRETS_H
#define SWAP_HUB_SECRETS_H

#define WIFI_SSID "Mei"
#define WIFI_PASSWORD "glrr010811"

#endif