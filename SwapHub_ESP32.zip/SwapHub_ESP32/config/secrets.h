#ifndef SWAP_HUB_SECRETS_H
#define SWAP_HUB_SECRETS_H

// ==========================================
// WIFI CONFIGURATION
// ==========================================

#define WIFI_SSID "mei"
#define WIFI_PASSWORD "21092006"

// ==========================================
// SWAPIT PRODUCTION API
// ==========================================

#define API_BASE_URL "https://swapitproject.web.id"

#define DEVICE_ID "SWAPHUB-BSD-001"
#define DEVICE_API_KEY "9wiM8ioOJvjYfpR26IUyxUB6LurpEOkSWzpMUgA0nTY"

#endif
